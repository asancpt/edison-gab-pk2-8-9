if (Sys.info()['sysname'] == 'Linux') { .libPaths('./lib') }

